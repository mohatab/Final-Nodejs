const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("./models/users");
const Book = require("./models/users");
const app = express();
require("dotenv").config();
const PORt = process.env.PORt || 5000;

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//Test Api
app.get("/", (req, res) => {
  res.send("Test get");
});

// Register
app.post("/api/register", async (req, res) => {
  const { username, password } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new User({
      username,
      password: hashedPassword,
    });

    await user.save();
    res.status(201).json({ message: "User registered successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Login
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    // Find the user
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check the password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid password" });
    }

    //JWT authentication
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });

    res.status(200).json({ message: "User log in successfully", token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

//Get all users
app.get("/api/users", async (req, res) => {
  try {
    const users = await User.find({});
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: err.message });
  }
});

//Get Single users by Id
app.get("/api/user/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const users = await User.findById(id);
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: err.message });
  }
});

//add users to data base
app.post("/api/users", async (req, res) => {
  try {
    const users = await User.create(req.body);
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update User
app.put("/api/user/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Find and update the user by ID
    const updatedUser = await User.findByIdAndUpdate(id, req.body, {
      new: true,
    });

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Return the updated user
    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

//Delete
app.delete("/api/user/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Find and Delete the user by ID
    const deletedUser = await User.findByIdAndDelete(id, req.body, {
      new: true,
    });

    if (!deletedUser) {
      return res.status(404).json({ message: "User not found" });
    }
    res.status(200).json({ message: "User deleted Successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

//Search
app.get("/api/search", async (req, res) => {
  const { author, genre } = req.query;

  let filter = {};

  if (author) {
    filter.author = { $regex: author, $options: "i" };
  }
  if (genre) {
    filter.genre = { $regex: genre, $options: "i" };
  }

  try {
    const books = await Book.find(filter);
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// database connection
mongoose.connect(process.env.DB_URI, {});
const db = mongoose.connection;
db.on("error", (error) => console.log(error));
db.once("open", () => console.log("connected to the database"));

app.listen(PORt, () => {
  console.log("Server started at http://localhost:5000");
});
